const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');

const cars = [];
let currentCarId = 1;

const carProtoPath = 'car.proto';
const carProtoDefinition = protoLoader.loadSync(carProtoPath, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});
const carProto = grpc.loadPackageDefinition(carProtoDefinition).car;

const carService = {
  addCar: (call, callback) => {
    const { brand, model, available } = call.request;

    const car = {
      car_id: currentCarId++,
      brand,
      model,
      available,
    };

    cars.push(car);
    callback(null, car);
  },

  getAllCars: (_, callback) => {
    callback(null, { cars });
  },

  getCarById: (call, callback) => {
    const { car_id } = call.request;
    const car = cars.find(c => c.car_id === car_id);

    if (!car) {
      return callback({
        code: grpc.status.NOT_FOUND,
        message: 'Voiture non trouvée',
      });
    }

    callback(null, car);
  },

  updateCar: (call, callback) => {
    const { car_id, brand, model, available } = call.request;
    const car = cars.find(c => c.car_id === car_id);

    if (!car) {
      return callback({
        code: grpc.status.NOT_FOUND,
        message: 'Voiture non trouvée',
      });
    }

    car.brand = brand || car.brand;
    car.model = model || car.model;
    car.available = available !== undefined ? available : car.available;

    callback(null, car);
  },

  deleteCar: (call, callback) => {
    const { car_id } = call.request;
    const index = cars.findIndex(c => c.car_id === car_id);

    if (index === -1) {
      return callback({
        code: grpc.status.NOT_FOUND,
        message: 'Voiture non trouvée',
      });
    }

    cars.splice(index, 1);

    callback(null, { message: 'Voiture supprimée avec succès' });
  }
};

const server = new grpc.Server();
server.addService(carProto.CarService.service, carService);
const port = 50052;
server.bindAsync(`0.0.0.0:${port}`, grpc.ServerCredentials.createInsecure(), () => {
  console.log(`Car microservice lancé sur le port ${port}`);
});
