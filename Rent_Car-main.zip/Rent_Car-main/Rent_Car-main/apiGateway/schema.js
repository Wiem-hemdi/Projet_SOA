const { gql } = require('@apollo/server');

const typeDefs = `#graphql
  type User {
    user_id: String!
    name: String!
    email: String!
  }

  type Car {
    car_id: String!
    brand: String!
    model: String!
    available: Boolean!
  }

  type Query {
    getUserById(user_id: String!): User
    getAllCars: [Car]
  }

  type Mutation {
    createUser(name: String!, email: String!, password: String!): User
    loginUser(email: String!, password: String!): User
    updateUser(user_id: String!, name: String, email: String, password: String): User
    deleteUser(user_id: String!): String

    createCar(brand: String!, model: String!, available: Boolean!): Car
    updateCar(car_id: String!, brand: String, model: String, available: Boolean): Car
    deleteCar(car_id: String!): String
  }
`;

module.exports = typeDefs;
