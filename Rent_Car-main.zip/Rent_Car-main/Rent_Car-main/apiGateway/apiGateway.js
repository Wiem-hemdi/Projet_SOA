// Importation des modules nécessaires

const express = require('express');
const { ApolloServer } = require('@apollo/server');
const { expressMiddleware } = require('@apollo/server/express4');
const bodyParser = require('body-parser');
const cors = require('cors');
const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');

// Importation du schéma GraphQL et des résolveurs
const typeDefs = require('./schema');
const resolvers = require('./resolvers');

// Initialisation de l'application Express
const app = express();
app.use(bodyParser.json());
app.use(cors());

// Chargement des fichiers .proto
const userProtoPath = './protos/user.proto';
const carProtoPath = './protos/car.proto';

// Chargement des définitions des fichiers .proto
const userProtoDef = protoLoader.loadSync(userProtoPath, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});
const carProtoDef = protoLoader.loadSync(carProtoPath, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});

// Chargement des services gRPC
const userProto = grpc.loadPackageDefinition(userProtoDef).user;
const carProto = grpc.loadPackageDefinition(carProtoDef).car;

// Création des clients gRPC
const clientUsers = new userProto.UserService(
  'user-service:50051',
  grpc.credentials.createInsecure()
);
const clientCars = new carProto.CarService(
  'car-service:50052',
  grpc.credentials.createInsecure()
);

// Création du serveur GraphQL
const server = new ApolloServer({
  typeDefs,
  resolvers,
});

// Fonction asynchrone pour démarrer le serveur
async function startServer() {
  await server.start();

  app.use(
    '/graphql',
    expressMiddleware(server, {
      context: async () => ({
        clientUsers,
        clientCars,
      }),
    })
  );

  // Routes REST pour le microservice des utilisateurs

  // Obtenir un utilisateur par ID
  app.get('/users/:id', (req, res) => {
    clientUsers.getUserById(
      { user_id: parseInt(req.params.id) },
      (err, response) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(response);
      }
    );
  });

  // Routes REST pour le microservice des voitures

  // Obtenir une voiture par ID
  app.post('/users', (req, res) => {
    const { name, email, password } = req.body;
    clientUsers.createUser({ name, email, password }, (err, response) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(response);
    });
  });

  // Obtenir une voiture par ID
  app.get('/cars/:id', (req, res) => {
    clientCars.getCarById(
      { car_id: parseInt(req.params.id) },
      (err, response) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(response);
      }
    );
  });

  // Obtenir toutes les voitures
  app.get('/cars', (req, res) => {
    clientCars.getAllCars({}, (err, response) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(response.cars);
    });
  });

  // Ajouter une nouvelle voiture
  app.post('/cars', (req, res) => {
    const { brand, model, available } = req.body;
    clientCars.addCar({ brand, model, available }, (err, response) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(response);
    });
  });

  // Démarrage de l'application sur le port 3000
  const port = 3000;
  app.listen(port, () => {
    console.log(` API Gateway running on http://localhost:${port}`);
  });
}
// Appel de la fonction pour démarrer le serveur
startServer();
