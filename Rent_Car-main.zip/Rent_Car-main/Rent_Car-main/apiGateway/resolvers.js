// Importation des modules gRPC
const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');

// Chargement du fichier .proto pour le service utilisateur
const userPackageDef = protoLoader.loadSync('./protos/user.proto', {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});
// Chargement du fichier .proto pour le service voiture
const carPackageDef = protoLoader.loadSync('./protos/car.proto', {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});
// Chargement des définitions de services gRPC
const userProto = grpc.loadPackageDefinition(userPackageDef).user;
const carProto = grpc.loadPackageDefinition(carPackageDef).car;

// Création des clients gRPC pour communiquer avec les microservices
const userClient = new userProto.UserService('user-service:50051', grpc.credentials.createInsecure());
const carClient = new carProto.CarService('car-service:50052', grpc.credentials.createInsecure());
// Définition des resolvers GraphQL
const resolvers = {
  Query: {
    getUserById: (_, { user_id }) => {
      return new Promise((resolve, reject) => {
        userClient.GetUserById({ user_id }, (err, res) => {
          if (err) reject(err);
          else resolve(res);
        });
      });
    },

  

    getAllCars: () => {
      return new Promise((resolve, reject) => {
        carClient.GetAllCars({}, (err, res) => {
          if (err) reject(err);
          else resolve(res.cars);
        });
      });
    },
  },

  Mutation: {
    createUser: (_, args) => {
      return new Promise((resolve, reject) => {
        userClient.CreateUser(args, (err, res) => {
          if (err) reject(err);
          else resolve(res);
        });
      });
    },

    loginUser: (_, args) => {
      return new Promise((resolve, reject) => {
        userClient.LoginUser(args, (err, res) => {
          if (err) reject(err);
          else resolve(res);
        });
      });
    },

    updateUser: (_, args) => {
      return new Promise((resolve, reject) => {
        userClient.UpdateUser(args, (err, res) => {
          if (err) reject(err);
          else resolve(res);
        });
      });
    },

    deleteUser: (_, { user_id }) => {
      return new Promise((resolve, reject) => {
        userClient.DeleteUser({ user_id }, (err, res) => {
          if (err) reject(err);
          else resolve(res.message);
        });
      });
    },

    createCar: (_, args) => {
      return new Promise((resolve, reject) => {
        carClient.CreateCar(args, (err, res) => {
          if (err) reject(err);
          else resolve(res);
        });
      });
    },

    updateCar: (_, args) => {
      return new Promise((resolve, reject) => {
        carClient.UpdateCar(args, (err, res) => {
          if (err) reject(err);
          else resolve(res);
        });
      });
    },

    deleteCar: (_, { car_id }) => {
      return new Promise((resolve, reject) => {
        carClient.DeleteCar({ car_id }, (err, res) => {
          if (err) reject(err);
          else resolve(res.message);
        });
      });
    },
  }
};

// Exportation des resolvers pour utilisation dans Apollo Server
module.exports = resolvers;
